function preload(){

}

function setup() {
 
}

function draw() {
 
}